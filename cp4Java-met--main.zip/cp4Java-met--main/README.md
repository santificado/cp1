# cp4Java-met-

André Lucas de Oliveira Santi - Rm94327
Gabriel Henrique Nascimento Paulino Santos - RM94430

Criar uma aplicação para gerenciamento de contas de um banco. O sistema deve ter cadastro de contas com titular, número, tipo (corrente, poupança, salário, etc.), ativa (sim ou não),  limite e saldo. O sistema deve validar as entradas de dados. Crie uma tela para listar as contas cadastradas, podendo ordenar por número, saldo ou nome do titular. Crie uma consulta para mostrar apenas as contas ativas.
