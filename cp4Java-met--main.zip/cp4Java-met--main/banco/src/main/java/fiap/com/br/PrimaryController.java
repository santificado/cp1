package fiap.com.br;


import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import fiap.com.br.model.Usuario;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;



public class PrimaryController implements Initializable{

    @FXML
    TextField textFieldNome;
    
    @FXML
    TextField textFieldNumero;
    
    @FXML
    ChoiceBox<String> choiceBoxConta;
    
    @FXML
    ChoiceBox<String> choiceBoxAtiva;

    @FXML
    TextField textFieldLimite;

    @FXML
    TextField textFieldSaldo;
    
    @FXML
    Button buttonSalvar;


    @FXML
    private ListView<Usuario> listView;

    private List<Usuario> lista = new ArrayList<>();

    public void salvar() {
        var usuario = carregarUsuarioDoBanco();
        lista.add(usuario);
    
        mostrarAlerta("Chamado cadastrado com sucesso");


        listView.getItems().add(usuario);}


    private void mostrarAlerta(String string) {
    }



    private Usuario carregarUsuarioDoBanco() {
        String nome = textFieldNome.getText();
        String numero = textFieldNumero.getText();
        String conta = choiceBoxConta.getValue();
        boolean ativa = choiceBoxAtiva.getValue() != null;

        return new Usuario(nome, numero, conta, ativa);

    }
        public void abrirConsulta() throws IOException{
        App.setRoot("consulta");
    }

    public void ordernarPorNumero() {
        
        lista.sort((o1, o2) -> Integer.compare(o1.getNumero(), o2.getNumero()));

        atualizarLista();

    }

    private void atualizarLista() {
        listView.getItems().clear();
        listView.getItems().addAll(lista);
    }
    

    public void ordernarPorSaldo() {

        lista.sort((o1, o2) -> Integer.compare(o1.getSaldo(), o2.getSaldo()));

        atualizarLista();

    }
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        choiceBoxConta.getItems().addAll(List.of("CONTA DEPÓSITO", "CONTA PAGAMENTO", "CONTA CORRENTE", "CONTA POUPANÇA", "CONTA SALÁRIO", "CONTA UNIVERSITÁRIA", "CONTA DIGITAL"));
        choiceBoxAtiva.getItems().addAll(List.of("ATIVA", "INATIVA"));    
    }

 
}


